package test8_5;

public class Dog extends Pet{
	public Dog(String name ,int age,String color,double price) {
		super(name,age,color,price);
	}
}
