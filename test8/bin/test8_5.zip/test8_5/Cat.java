package test8_5;

public class Cat extends Pet{
	public Cat(String name ,int age,String color,double price) {
		super(name,age,color,price);
	}
}
