package test8_5;

public class Duck extends Pet{
	public Duck(String name ,int age,String color,double price) {
		super(name,age,color,price);
	}
}
