package test8_5;

public class Rabbit extends Pet{
	public Rabbit(String name ,int age,String color,double price) {
		super(name,age,color,price);
	}
}
