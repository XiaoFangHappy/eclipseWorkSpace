package test8_5;

public class Pig extends Pet{
	public Pig(String name ,int age,String color,double price) {
		super(name,age,color,price);
	}
}
